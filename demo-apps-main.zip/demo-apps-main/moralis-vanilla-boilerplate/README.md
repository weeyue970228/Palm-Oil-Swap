# vanilla-boilerplate
Boilerplate Moralis Project made with vanilla JS
