export const environment = {
  production: true,
  name: 'prod',
  app_id: 'suTLP5hyFAPMyPx131t0TPt9eWSsMU8zuNoP0GzS',
  server_url: 'https://orpp979dzre5.grandmoralis.com:2053/server'
};
