import React from 'react'

export default function Home() {
  return (
    <div>
      <p>Moralis blockchian explorer</p>
    </div>
  )
}
