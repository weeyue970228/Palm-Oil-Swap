import { defaultEnv, Env } from './env';

export const environment: Env = {
  ...defaultEnv,
  production: true
};
