module.exports = {
  transpileDependencies: ["vuex-module-decorators"],
};
