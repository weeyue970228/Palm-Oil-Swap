# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## 

Get started 

`yarn install`

Start the app

`yarn start`

View [src/index](src/index.js)
