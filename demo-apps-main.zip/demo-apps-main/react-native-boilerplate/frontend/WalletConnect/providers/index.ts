export { default as WalletConnectProvider } from "./WalletConnectProvider";
