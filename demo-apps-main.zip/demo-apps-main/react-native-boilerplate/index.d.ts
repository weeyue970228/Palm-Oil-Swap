declare module '@env' {
   export const HARDHAT_PORT: string;
   export const HARDHAT_PRIVATE_KEY: string;
}